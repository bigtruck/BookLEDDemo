
// BookLED_DemoDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BookLED_Demo.h"
#include "BookLED_DemoDlg.h"
#include "afxdialogex.h"
#include <Windows.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#define TID_TIMER1	1
#define TID_TIMER2	2

// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CBookLED_DemoDlg �Ի���



CBookLED_DemoDlg::CBookLED_DemoDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CBookLED_DemoDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CBookLED_DemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTON_OPENCOM, m_Button_OpenCOM);
	DDX_Control(pDX, IDC_COMBO_PORTLIST, m_ComboBox_PortList);
}

BEGIN_MESSAGE_MAP(CBookLED_DemoDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_OPENCOM, &CBookLED_DemoDlg::OnBnClickedOpenCommonPort)
	ON_CBN_SELCHANGE(IDC_COMBO_PORTLIST, &CBookLED_DemoDlg::OnCbnSelchangeComboPortlist)
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CBookLED_DemoDlg ��Ϣ��������

BOOL CBookLED_DemoDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	m_Button_OpenCOM.SetWindowTextW(L"��") ;
	ScanCommonPort(&m_ComboBox_PortList) ;
	m_ComboBox_PortList.SetCurSel(0) ;
	portOpen = FALSE ;

	//m_pThreadDemoMain = (DemoMain *)AfxBeginThread(RUNTIME_CLASS(DemoMain), 0, 0, CREATE_SUSPENDED);
	//m_pThreadDemoMain = (DemoMain *)AfxBeginThread(RUNTIME_CLASS(DemoMain), 0, 0, CREATE_SUSPENDED);
	


	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CBookLED_DemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CBookLED_DemoDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CBookLED_DemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CBookLED_DemoDlg::ScanCommonPort(CComboBox *combobox)
{
	#define MAX_KEY_LENGTH   255
	#define MAX_VALUE_NAME  16383
	HKEY hTestKey;
	if(ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("HARDWARE\\DEVICEMAP\\SERIALCOMM"), 0, KEY_READ, &hTestKey) )
	{
		TCHAR   achClass[MAX_PATH] = TEXT(""); // buffer for class name
		DWORD   cchClassName = MAX_PATH; // size of class string
		DWORD   cSubKeys=0;                  // number of subkeys
		DWORD   cbMaxSubKey;             // longest subkey size
		DWORD   cchMaxClass;             // longest class string
		DWORD   cValues;             // number of values for key
		DWORD   cchMaxValue;         // longest value name
		DWORD   cbMaxValueData;      // longest value data
		DWORD   cbSecurityDescriptor; // size of security descriptor
		FILETIME ftLastWriteTime;     // last write time
 
		DWORD i, retCode;
		//TCHAR achValue[MAX_VALUE_NAME];
		CHAR achValue[MAX_VALUE_NAME];
		DWORD cchValue = MAX_VALUE_NAME;
		LONG lResult ;
 
		// Get the class name and the value count.
		retCode = RegQueryInfoKey(
					hTestKey,                   // key handle
					achClass,               // buffer for class name
					&cchClassName,          // size of class string
					NULL,                   // reserved
					&cSubKeys,              // number of subkeys
					&cbMaxSubKey,           // longest subkey size
					&cchMaxClass,           // longest class string
					&cValues,               // number of values for this key
					&cchMaxValue,           // longest value name
					&cbMaxValueData,        // longest value data
					&cbSecurityDescriptor,  // security descriptor
					&ftLastWriteTime);      // last write time
		if (cValues > 0)
		{
			int nIndex = -1;
			for (i=0; i<cValues; i++)
			{
				cchValue = MAX_VALUE_NAME; 
				achValue[0] = '\0';
				lResult = RegEnumValueA(hTestKey, i, achValue, &cchValue, NULL, NULL, NULL, NULL) ;
				if (ERROR_SUCCESS == lResult)
				{
					BYTE strDSName[50];
					//memset(strDSName, 0, 100);
					strDSName[0] = '\n' ;
					DWORD  nBuffLen = 50;
					//if (ERROR_SUCCESS == RegQueryValueEx(hTestKey, (LPCTSTR)achValue, NULL,&nValueType, strDSName, &nBuffLen))
					if (ERROR_SUCCESS == RegQueryValueExA(hTestKey, achValue, NULL,NULL, strDSName, &nBuffLen))
					{	
						CString str(strDSName) ;
						combobox->AddString(str) ;
					}
				}
				else
				{
					TRACE("error\r\n") ;
				}
			}
		}
		else
		{
			//AfxMessageBox(_T("PC��û��COM��....."));
		}
	}
	RegCloseKey(hTestKey);
}

BOOL CBookLED_DemoDlg::OpenCommonPort(CString portName)
{	
	DCB dcb ;
	BOOL fRetVal ;
	COMMTIMEOUTS CommTimeOuts;
	CString szCom;
	szCom = L"\\\\.\\" + portName ;
	//COMFile = CreateFile(szCom.GetBuffer(50), GENERIC_READ | GENERIC_WRITE,//
	COMFile = CreateFile(szCom, GENERIC_READ | GENERIC_WRITE,//
		FILE_SHARE_READ | FILE_SHARE_WRITE,                                                                                
		NULL,
		OPEN_EXISTING,
		FILE_FLAG_OVERLAPPED,
		NULL);
	if (INVALID_HANDLE_VALUE == COMFile){
		return ( FALSE ) ;
	}

	SetupComm(COMFile,6000,6000) ;
	SetCommMask(/*COMFileTemp*/COMFile, EV_RXCHAR ) ;
	CommTimeOuts.ReadIntervalTimeout = 0xFFFFFFFF ;
	CommTimeOuts.ReadTotalTimeoutMultiplier = 0 ;
	CommTimeOuts.ReadTotalTimeoutConstant = 1000 ;
	CommTimeOuts.WriteTotalTimeoutMultiplier = 2*CBR_115200/115200 ;
	CommTimeOuts.WriteTotalTimeoutConstant = 0 ;
	SetCommTimeouts(/*COMFileTemp*/COMFile, &CommTimeOuts ) ;

	dcb.DCBlength = sizeof( DCB ) ;
	GetCommState(COMFile, &dcb ) ;
	dcb.BaudRate =CBR_115200;
	dcb.StopBits =ONESTOPBIT;
	dcb.Parity = NOPARITY;
	dcb.ByteSize=8;
	dcb.fBinary=TRUE;
	dcb.fOutxDsrFlow = 0 ;
	dcb.fDtrControl = DTR_CONTROL_ENABLE ;
	dcb.fOutxCtsFlow = 0 ;
	dcb.fRtsControl = RTS_CONTROL_ENABLE ;
	dcb.fInX = dcb.fOutX = 1 ;
	dcb.XonChar = 0X11 ;
	dcb.XoffChar = 0X13 ;
	dcb.XonLim = 100 ;
	dcb.XoffLim = 100 ;
	dcb.fParity = TRUE ;

	fRetVal = SetCommState(/*COMFileTemp*/COMFile, &dcb ) ;

	if(!fRetVal)
	{
		return FALSE;
	}

	PurgeComm( /*COMFileTemp*/COMFile, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR ) ;
	EscapeCommFunction( /*COMFileTemp*/COMFile, SETDTR ) ; 

	return TRUE ;
}

void CBookLED_DemoDlg::OnBnClickedOpenCommonPort()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if ( portOpen == FALSE )
	{
		CString str ;
		WCHAR text_buff[255] ;
		m_ComboBox_PortList.GetLBText(m_ComboBox_PortList.GetCurSel(),text_buff) ;
		str = text_buff ;
		if ( OpenCommonPort(str) == FALSE )
		{
			MessageBox(L"�򿪴���ʧ��",L"",MB_OK | MB_ICONERROR) ;
		}
		else
		{
			MessageBox(L"�򿪴��ڳɹ�",L"",MB_OK) ;
			m_Button_OpenCOM.SetWindowTextW(L"�ر�") ;
			portOpen = TRUE ;
			SetTimer(TID_TIMER1, 500, 0);
		}
	}
	else
	{
		CloseCommonPort() ;
	}
}

void CBookLED_DemoDlg::CloseCommonPort(void)
{
	if ( portOpen == TRUE )
	{
		KillTimer(TID_TIMER1);
		//��ֹ���ж˿������¼�
		SetCommMask(COMFile, 0) ;
		//��������ն˾����ź�
		EscapeCommFunction( COMFile, CLRDTR ) ;
		//����ͨ����Դ����������뻺�����ַ�����ֹ��ͨ����Դ�Ϲ���Ķ���д�ٲ���
		PurgeComm( COMFile, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR ) ;
		CloseHandle( COMFile );
		COMFile = NULL;
		m_Button_OpenCOM.SetWindowTextW(L"��") ;
		portOpen = FALSE ;
	}
}


void CBookLED_DemoDlg::OnCbnSelchangeComboPortlist()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	//if (KillTimer(TID_TIMER1) == FALSE)
	//{
	//	MessageBox(L"�رն�ʱ��ʧ��");
	//}
	CloseCommonPort() ;
}



void CBookLED_DemoDlg::OnTimer(UINT_PTR nIDEvent)
{
	static int t;
	BYTE data[] = "Hello\r\n";
	DWORD len;
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	/*
	if (++t >= 100)
	{
		t = 0;
		TRACE("t1s\r\n");
	}
	*/
	if (!WriteFile(COMFile, data, sizeof(data), &len, NULL))
	{
		TRACE("send err\r\n");
	}
	TRACE("send\r\n");


	CDialogEx::OnTimer(nIDEvent);
}
