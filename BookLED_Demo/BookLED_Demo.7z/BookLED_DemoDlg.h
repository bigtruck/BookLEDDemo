
// BookLED_DemoDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"

#include "DemoMain.h"
// CBookLED_DemoDlg �Ի���
class CBookLED_DemoDlg : public CDialogEx
{
// ����
public:
	CBookLED_DemoDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_BOOKLED_DEMO_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CButton m_Button_OpenCOM;
	CComboBox m_ComboBox_PortList;
	void ScanCommonPort(CComboBox *combobox) ;
	void CloseCommonPort(void) ;
	BOOL OpenCommonPort(CString portName) ;
	BOOL portOpen ;
	HANDLE COMFile ;
	DemoMain *m_pThreadDemoMain;
	
	
	afx_msg void OnBnClickedOpenCommonPort();
	afx_msg void OnCbnSelchangeComboPortlist();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
